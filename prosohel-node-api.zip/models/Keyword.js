const mongoose = require('mongoose');
const { default: slugify } = require('slugify');

const KeywordSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, 'Please add keyword name'],
      trim: true,
      unique: true,
    },
    isActive: {
      type: Boolean,
      default: true,
    }
  },
  {
    toJSON: { virtuals: true },
    toObject: { virtuals: true },
    timestamps: true
  }
);



module.exports = mongoose.model('Keywords', KeywordSchema);
